#include "mbed.h"
#include "LIS331.h"

//setup
float y;
float x;
DigitalOut Int1(D2);
DigitalOut Int2(D3);
LIS331 accelerometer(D4, D5); // entree I2C de l'accelerometre   *Format(sda, scl)*
Serial pc(USBTX, USBRX);
char test = NULL;

//fonction pour display des floats



//comportement
int main(void){
    while(1){
        test = accelerometer.getInterruptConfiguration();
        pc.printf("%f\t",accelerometer.getAccelY());
        pc.printf("%f\n\r",accelerometer.getAccelX());
        wait(1);
        //har test = D1;
        pc.printf("Maintenant la valeur de Int1:");
        pc.printf("%d\n\r",Int1.read());
        wait(1);
        pc.printf("Maintenant la valeur de Int2:");
        pc.printf("%d\n\r",Int1.read());
        wait(1);
        
              
    }
}
    
    