#include "mbed.h"
#include "Air_Quality_Sensor.h"

AnalogIn air(A0);
Serial pc(USBTX, USBRX);
AirQualitySensor airqualitysensor(A0);
int current_quality =-1;
void setup()
{
    //Serial.begin(9600);
    airqualitysensor.init(A0);
}
void loop()
{
    wait(1);
    pc.printf("AirQuality value: %d \n\r", air.read());
    current_quality=airqualitysensor.slope();
    if (current_quality >= 0)// if a valid data returned.
    {
        if (current_quality==0)
            pc.printf("High pollution! Force signal active\n\r");
        else if (current_quality==1)
            pc.printf("High pollution!\n\r");
        else if (current_quality==2)
            pc.printf("Low pollution!\n\r");
        else if (current_quality ==3)
            pc.printf("Fresh air\n\r");
    }
}
/*R(TIMER2_OVF_vect)
{
    if(airqualitysensor.counter==122)//set 2 seconds as a detected duty
    {
        airqualitysensor.last_vol=airqualitysensor.first_vol;
        airqualitysensor.first_vol=analogRead(A0);
        airqualitysensor.counter=0;
        airqualitysensor.timer_index=1;
        PORTB=PORTB^0x20;
            }
    else
    {
        airqualitysensor.counter++;
    }
}
    }
    else
    {
        airqualitysensor.counter++;
    }
}
*/
int main(void){
    setup();
    while(1)
    {
        loop();
    }
    }